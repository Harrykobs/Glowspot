"""Database layer. Runs on SQLite (default, local) or PostgreSQL (set DATABASE_URL, e.g. Supabase).

All SQL in the app is written once with ? placeholders and works on both. The small Conn wrapper
translates the few differences (placeholders, RETURNING id, dates in East Africa Time).
"""
import re
import sqlite3
from datetime import datetime, timedelta

from flask import current_app, g

try:  # PostgreSQL support is optional so the app still runs locally with only SQLite
    import psycopg
    from psycopg.rows import dict_row
    IntegrityErrors = (sqlite3.IntegrityError, psycopg.errors.IntegrityError)
except ImportError:  # pragma: no cover
    psycopg = None
    IntegrityErrors = (sqlite3.IntegrityError,)

DEFAULT_SETTINGS = {
    "first_skin_price": ("15000", "Skin analysis price: first visit and standard price (TZS)"),
    "returning_skin_price": ("10000", "Skin analysis price for returning customers who qualify (TZS)"),
    "referral_reward": ("2000", "Reward for a referred customer's first skin analysis (TZS)"),
    "package_commission_percent": ("8", "Package commission on each confirmed payment (%)"),
    "min_referrals_for_discount": ("2", "Qualifying referrals needed for the returning-customer price"),
}

TABLES = ["users", "customers", "referral_changes", "settings", "settings_history", "packages",
          "sales", "payments", "payouts", "commissions", "audit"]
NO_ID_TABLES = {"settings"}

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id {PK},
  username TEXT NOT NULL,
  full_name TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('staff','manager')),
  active INTEGER NOT NULL DEFAULT 1,
  must_change_password INTEGER NOT NULL DEFAULT 0,
  failed_logins INTEGER NOT NULL DEFAULT 0,
  locked_until TEXT,
  created_at TEXT NOT NULL,
  last_login TEXT
);
CREATE TABLE IF NOT EXISTS customers(
  id {PK},
  name TEXT NOT NULL,
  phone TEXT NOT NULL UNIQUE,
  referrer_id INTEGER REFERENCES customers(id),
  registered_at TEXT NOT NULL,
  registered_by INTEGER NOT NULL REFERENCES users(id),
  is_demo INTEGER NOT NULL DEFAULT 0,
  CHECK(referrer_id IS NULL OR referrer_id <> id)
);
CREATE INDEX IF NOT EXISTS idx_customers_referrer ON customers(referrer_id);
CREATE TABLE IF NOT EXISTS referral_changes(
  id {PK},
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  old_referrer_id INTEGER REFERENCES customers(id),
  new_referrer_id INTEGER REFERENCES customers(id),
  reason TEXT NOT NULL,
  changed_by INTEGER NOT NULL REFERENCES users(id),
  changed_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS settings(
  key TEXT PRIMARY KEY, value TEXT NOT NULL, label TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS settings_history(
  id {PK}, key TEXT NOT NULL, old_value TEXT, new_value TEXT NOT NULL,
  reason TEXT NOT NULL, changed_by INTEGER NOT NULL REFERENCES users(id), changed_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS packages(
  id {PK},
  name TEXT NOT NULL,
  price INTEGER NOT NULL CHECK(price > 0),
  active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS sales(
  id {PK},
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  kind TEXT NOT NULL CHECK(kind IN ('skin','package')),
  item_name TEXT NOT NULL,
  original_price INTEGER NOT NULL,
  discount INTEGER NOT NULL DEFAULT 0,
  amount_due INTEGER NOT NULL,
  is_first_skin INTEGER NOT NULL DEFAULT 0,
  price_note TEXT,
  service_date TEXT NOT NULL,
  recorded_by INTEGER NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','voided')),
  void_reason TEXT, voided_by INTEGER REFERENCES users(id), voided_at TEXT,
  CHECK(discount >= 0 AND amount_due > 0 AND amount_due = original_price - discount)
);
CREATE INDEX IF NOT EXISTS idx_sales_customer ON sales(customer_id);
CREATE TABLE IF NOT EXISTS payments(
  id {PK},
  sale_id INTEGER NOT NULL REFERENCES sales(id),
  amount INTEGER NOT NULL CHECK(amount > 0),
  method TEXT NOT NULL CHECK(method IN ('Cash','Mobile money','Bank transfer','Card')),
  paid_on TEXT NOT NULL,
  recorded_by INTEGER NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'confirmed' CHECK(status IN ('confirmed','reversed')),
  reversed_reason TEXT, reversed_by INTEGER REFERENCES users(id), reversed_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_payments_sale ON payments(sale_id);
CREATE TABLE IF NOT EXISTS payouts(
  id {PK},
  referrer_id INTEGER NOT NULL REFERENCES customers(id),
  amount INTEGER NOT NULL,
  method TEXT NOT NULL CHECK(method IN ('Cash','Mobile money','Bank transfer','Card')),
  paid_on TEXT NOT NULL,
  recorded_by INTEGER NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL,
  note TEXT
);
CREATE TABLE IF NOT EXISTS commissions(
  id {PK},
  referrer_id INTEGER NOT NULL REFERENCES customers(id),
  referred_id INTEGER NOT NULL REFERENCES customers(id),
  sale_id INTEGER NOT NULL REFERENCES sales(id),
  payment_id INTEGER REFERENCES payments(id),
  kind TEXT NOT NULL CHECK(kind IN ('skin_reward','package_commission','adjustment')),
  base_amount INTEGER NOT NULL,
  rate_label TEXT NOT NULL,
  amount INTEGER NOT NULL,
  earned_at TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('Pending','Approved','Paid','Reversed')),
  approved_by INTEGER REFERENCES users(id), approved_at TEXT,
  payout_id INTEGER REFERENCES payouts(id),
  reverses_id INTEGER REFERENCES commissions(id),
  reversed_at TEXT, reversed_by INTEGER REFERENCES users(id), reversal_reason TEXT
);
CREATE INDEX IF NOT EXISTS idx_comm_referrer ON commissions(referrer_id);
CREATE INDEX IF NOT EXISTS idx_comm_sale ON commissions(sale_id);
-- One active first-skin-analysis reward per referred customer (database-level guard).
CREATE UNIQUE INDEX IF NOT EXISTS uq_skin_reward ON commissions(referred_id)
  WHERE kind='skin_reward' AND reversed_at IS NULL;
-- One package commission per confirmed payment.
CREATE UNIQUE INDEX IF NOT EXISTS uq_pkg_commission ON commissions(payment_id)
  WHERE kind='package_commission';
CREATE TABLE IF NOT EXISTS audit(
  id {PK},
  user_id INTEGER, username TEXT,
  action TEXT NOT NULL, entity TEXT, entity_id INTEGER,
  detail TEXT, reason TEXT, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit(created_at);
CREATE UNIQUE INDEX IF NOT EXISTS uq_users_username ON users(lower(username));
CREATE UNIQUE INDEX IF NOT EXISTS uq_packages_name ON packages(lower(name));
"""

VIEWS = """CREATE VIEW sale_totals AS
  SELECT s.id AS sale_id, s.customer_id, s.kind, s.amount_due, s.status, s.service_date, s.is_first_skin,
         COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.sale_id=s.id AND p.status='confirmed'),0) AS paid
  FROM sales s;
-- A "qualifying paid visit": package with a confirmed payment, or skin analysis paid in full.
CREATE VIEW qualifying_sales AS
  SELECT * FROM sale_totals
  WHERE status='active' AND ((kind='package' AND paid>0) OR (kind='skin' AND paid>=amount_due));
"""


def is_postgres(target):
    return str(target).startswith(("postgres://", "postgresql://"))


def pg_sql(sql):
    """Translate app SQL (written with ? placeholders) for PostgreSQL."""
    return sql.replace("%", "%%").replace("?", "%s")


def _eat_date(value):
    if not value:
        return None
    return (datetime.strptime(value, "%Y-%m-%d %H:%M:%S") + timedelta(hours=3)).strftime("%Y-%m-%d")


class PgResult:
    """Gives a PostgreSQL cursor the bits of the sqlite3 cursor API the app uses."""

    def __init__(self, cur, lastrowid=None):
        self._cur, self.lastrowid = cur, lastrowid

    @property
    def rowcount(self):
        return self._cur.rowcount

    @property
    def description(self):
        return self._cur.description

    def fetchone(self):
        return self._cur.fetchone()

    def fetchall(self):
        return self._cur.fetchall()


class Conn:
    def __init__(self, raw, pg):
        self.raw, self.pg = raw, pg

    def execute(self, sql, params=()):
        if not self.pg:
            return self.raw.execute(sql, params)
        sql = pg_sql(sql)
        m = re.match(r"\s*INSERT\s+INTO\s+(\w+)", sql, re.I)
        returning = bool(m) and m.group(1).lower() not in NO_ID_TABLES and "RETURNING" not in sql.upper()
        cur = self.raw.cursor()
        cur.execute(sql + (" RETURNING id" if returning else ""), params)
        return PgResult(cur, cur.fetchone()["id"] if returning else None)

    def commit(self):
        self.raw.commit()

    def rollback(self):
        self.raw.rollback()

    def close(self):
        self.raw.close()


def connect(target):
    """target = path to a SQLite file, or a postgresql:// URL."""
    if is_postgres(target):
        if psycopg is None:
            raise RuntimeError("DATABASE_URL is set but the 'psycopg' package is not installed.")
        url = target if "sslmode=" in target else target + ("&" if "?" in target else "?") + "sslmode=require"
        raw = psycopg.connect(url, row_factory=dict_row, prepare_threshold=None, connect_timeout=15)
        return Conn(raw, True)
    raw = sqlite3.connect(target, timeout=15)
    raw.row_factory = sqlite3.Row
    raw.execute("PRAGMA foreign_keys=ON")
    raw.create_function("eat_date", 1, _eat_date, deterministic=True)
    return Conn(raw, False)


def get_db():
    if "db" not in g:
        g.db = connect(current_app.config["DATABASE"])
    return g.db


def close_db(exc=None):
    conn = g.pop("db", None)
    if conn is not None:
        if exc is not None:
            conn.rollback()
        conn.close()


def _statements(text):
    lines = [ln for ln in text.splitlines() if not ln.strip().startswith("--")]
    return [s.strip() for s in "\n".join(lines).split(";") if s.strip()]


def init_db(conn):
    """Create tables if missing and insert default settings. Safe to run repeatedly."""
    if conn.pg:
        conn.execute("SELECT pg_advisory_lock(727272)")  # two workers starting together must not collide
        try:
            for stmt in _statements(SCHEMA.replace("{PK}", "INTEGER GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY")):
                conn.execute(stmt)
            conn.execute("CREATE OR REPLACE FUNCTION eat_date(t text) RETURNS text AS $$ "
                         "SELECT to_char((t::timestamp + interval '3 hours'), 'YYYY-MM-DD') $$ LANGUAGE sql IMMUTABLE")
            for stmt in _statements(VIEWS.replace("CREATE VIEW", "CREATE OR REPLACE VIEW")):
                conn.execute(stmt)
            _lock_down_postgres(conn)
            _seed_settings(conn)
            conn.commit()
        finally:
            conn.rollback()
            conn.execute("SELECT pg_advisory_unlock(727272)")
            conn.commit()
        return
    conn.raw.execute("PRAGMA journal_mode=WAL")
    for stmt in _statements(SCHEMA.replace("{PK}", "INTEGER PRIMARY KEY")):
        conn.execute(stmt)
    for stmt in _statements(VIEWS.replace("CREATE VIEW", "CREATE VIEW IF NOT EXISTS")):
        conn.execute(stmt)
    _seed_settings(conn)
    conn.execute("PRAGMA user_version=1")
    conn.commit()


def _seed_settings(conn):
    for key, (value, label) in DEFAULT_SETTINGS.items():
        conn.execute("INSERT INTO settings(key,value,label) VALUES(?,?,?) ON CONFLICT(key) DO NOTHING", (key, value, label))


def _lock_down_postgres(conn):
    """Supabase exposes the public schema through a web API. Block that API from these tables:
    turn on row-level security (with no policies) and remove access for the API roles. The app itself
    connects as the database owner, which is not affected."""
    for t in TABLES:
        conn.execute(f"ALTER TABLE {t} ENABLE ROW LEVEL SECURITY")
    for v in ("sale_totals", "qualifying_sales"):
        conn.execute(f"ALTER VIEW {v} SET (security_invoker = true)")
    conn.execute(
        "DO $$ BEGIN IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='anon') THEN "
        "REVOKE ALL ON ALL TABLES IN SCHEMA public FROM anon, authenticated; "
        "REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM anon, authenticated; "
        "REVOKE ALL ON ALL FUNCTIONS IN SCHEMA public FROM anon, authenticated; "
        "END IF; END $$")
