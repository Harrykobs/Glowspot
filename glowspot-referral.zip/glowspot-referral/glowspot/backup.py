"""Portable backup: every table as a CSV file inside one ZIP. Works on SQLite and PostgreSQL."""
import csv
import io
import zipfile

from .db import TABLES


def export_zip(db):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for t in TABLES:
            cur = db.execute(f"SELECT * FROM {t} ORDER BY {'key' if t == 'settings' else 'id'}")
            cols = [c[0] for c in cur.description]
            out = io.StringIO()
            w = csv.writer(out)
            w.writerow(cols)
            for row in cur.fetchall():
                w.writerow(["" if row[c] is None else row[c] for c in cols])
            z.writestr(f"{t}.csv", out.getvalue())
    return buf.getvalue()


def int_columns(db, table):
    if db.pg:
        rows = db.execute("SELECT column_name AS name FROM information_schema.columns WHERE table_schema='public' "
                          "AND table_name=? AND data_type IN ('integer','bigint','smallint')", (table,)).fetchall()
        return {r["name"] for r in rows}
    return {r["name"] for r in db.execute(f"PRAGMA table_info({table})").fetchall() if r["type"].upper() == "INTEGER"}


def import_zip(db, data, replace=False):
    """Load a backup ZIP made by export_zip. With replace=True the existing data is deleted first."""
    z = zipfile.ZipFile(io.BytesIO(data))
    missing = [t for t in TABLES if f"{t}.csv" not in z.namelist()]
    if missing:
        raise ValueError("Not a Glowspot backup; missing " + ", ".join(missing))
    if replace:
        for t in reversed(TABLES):
            db.execute(f"DELETE FROM {t}")
    elif db.execute("SELECT COUNT(*) c FROM customers").fetchone()["c"]:
        raise ValueError("The database already has customers. Use replace to overwrite it.")
    counts = {}
    for t in TABLES:
        ints = int_columns(db, t)
        if t == "settings":
            db.execute("DELETE FROM settings")  # drop the defaults created at start-up; the backup has the real values
        rows = list(csv.DictReader(io.StringIO(z.read(f"{t}.csv").decode("utf-8"))))
        deferred = []
        for r in rows:
            vals = {k: (None if v == "" else (int(v) if k in ints else v)) for k, v in r.items()}
            if t == "customers" and vals.get("referrer_id") is not None:  # referrer may have a later id
                deferred.append((vals["id"], vals["referrer_id"]))
                vals["referrer_id"] = None
            cols = list(vals)
            db.execute(f"INSERT INTO {t}({','.join(cols)}) VALUES({','.join('?' * len(cols))})", [vals[c] for c in cols])
        for cid, ref in deferred:
            db.execute("UPDATE customers SET referrer_id=? WHERE id=?", (ref, cid))
        if db.pg and t != "settings":
            db.execute(f"SELECT setval(pg_get_serial_sequence('{t}','id'), COALESCE(MAX(id),1), MAX(id) IS NOT NULL) FROM {t}")
        counts[t] = len(rows)
    db.commit()
    return counts
