#!/usr/bin/env python3
"""Restore (or move) all data from a backup ZIP made by Manage > Backup. Works for SQLite and PostgreSQL.

Usage:
  DATABASE_URL=postgresql://...  python scripts/restore_csv.py BACKUP.zip            (empty database only)
  DATABASE_URL=postgresql://...  python scripts/restore_csv.py BACKUP.zip --replace  (ERASES current data first)
Without DATABASE_URL it uses DATABASE_PATH (default instance/glowspot.db).
Run it from the project folder. Stop the website first when replacing live data.
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from glowspot import backup, db  # noqa: E402

p = argparse.ArgumentParser()
p.add_argument("zipfile")
p.add_argument("--replace", action="store_true", help="delete all existing data before loading")
a = p.parse_args()
target = os.environ.get("DATABASE_URL") or os.environ.get("DATABASE_PATH", "instance/glowspot.db")
if a.replace and input("This ERASES everything in the target database. Type YES to continue: ") != "YES":
    sys.exit("Cancelled.")
conn = db.connect(target)
db.init_db(conn)
try:
    counts = backup.import_zip(conn, open(a.zipfile, "rb").read(), replace=a.replace)
except Exception as e:  # noqa: BLE001
    conn.rollback()
    sys.exit(f"Restore failed, nothing was changed: {e}")
print("Restored:", ", ".join(f"{t}={n}" for t, n in counts.items()))
