# Free hosting: Render (website) + Supabase (database)

Prices and limits change; check each site's current free-plan terms before storing real customer data.

## A. Supabase (database)
1. supabase.com > sign up (GitHub login is easiest) > New project (inside an organization).
2. Name: glowspot. Database password: letters and numbers only, write it down. Region: nearest (Africa/Cape Town if offered). Plan: Free. Create project and wait until it is ready.
3. Click Connect (top bar) > Connection string > choose the **Session pooler** URI. Copy it. It looks like `postgresql://postgres.xxxx:[YOUR-PASSWORD]@aws-0-REGION.pooler.supabase.com:5432/postgres`. Replace `[YOUR-PASSWORD]` (including the brackets) with your real password.
4. Keep that full string private. It goes only into Render, never into GitHub or chat.
The app creates its own tables on first start. It also switches on row-level security so Supabase's public web API cannot read your tables.

## B. GitHub
Upload the new files into the `glowspot-referral` folder of your repository (Add file > Upload files; same names overwrite the old ones).

## C. Render
New > Blueprint > your repository > Blueprint Path `glowspot-referral/render.yaml` > Retry. Enter DATABASE_URL (the string from A3) and INITIAL_ADMIN_PASSWORD, then deploy.
Check `https://YOUR-SITE.onrender.com/healthz` shows ok, then log in as `admin`.

## Known behaviour of the free plans
- Render free web services sleep after about 15 minutes without visits; the next visit takes up to a minute to wake.
- Supabase free projects pause after about a week of no use; restore from the Supabase dashboard. Keep your own backups.
