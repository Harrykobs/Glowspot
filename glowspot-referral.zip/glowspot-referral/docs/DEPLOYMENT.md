# Deployment and migration

The app is one Python web process plus a database. The database is **SQLite** (a file, for local use) or **PostgreSQL** (set `DATABASE_URL`; recommended for hosting, e.g. Supabase).
Step-by-step for the free Render + Supabase setup: see SUPABASE_RENDER_GUIDE.md.

## Environment variables
| Name | Purpose |
|---|---|
| `APP_ENV=production` | enforces SECRET_KEY, secure cookies, HSTS |
| `SECRET_KEY` | long random text; keeps logins safe (Render can generate it) |
| `DATABASE_URL` | PostgreSQL connection string. If empty, SQLite at `DATABASE_PATH` is used |
| `TRUST_PROXY=1` | when the host terminates HTTPS in front of the app |
| `INITIAL_ADMIN_USERNAME` / `INITIAL_ADMIN_PASSWORD` | creates the first manager when there are no users yet (must change password at first login) |
| `SEED_DEMO=1`, `TEST_BANNER` | test site only: synthetic demo data and a banner |

## Other hosts
- **Any Linux server / VPS:** `pip install -r requirements.txt`, then `APP_ENV=production SECRET_KEY=... DATABASE_URL=... gunicorn wsgi:app --workers 1 --threads 4`, behind Nginx or Caddy for HTTPS, run under systemd.
- **Docker:** `docker build -t glowspot .` then `docker run -p 8000:8000 -e APP_ENV=production -e SECRET_KEY=... -e DATABASE_URL=... -e INITIAL_ADMIN_PASSWORD=... glowspot`.
- **SQLite on a paid disk (Render Starter):** drop DATABASE_URL, set `DATABASE_PATH=/var/data/glowspot.db` and add a disk. Not needed with Supabase.

## Own domain
Add the domain in your host's dashboard, then create the DNS record it shows (a CNAME for a subdomain such as app.yourdomain.com). The host issues the HTTPS certificate.

## Moving data between hosts or databases (SQLite to Supabase, or Supabase to another server)
1. Log in as manager, Manage > Backup > Download backup (ZIP of CSV files).
2. Point `DATABASE_URL` (or `DATABASE_PATH`) at the new, empty database and run `python scripts/restore_csv.py BACKUP.zip` from the project folder.
3. Check the customer count and a few balances, then switch over. Use `--replace` only when you intend to erase the target's data.

## Backups
Download a backup from the website at least weekly and keep copies off the host (Google Drive, a USB stick). Free Supabase plans may not include downloadable automatic backups, so do not rely on them.

## Before real use
Start from a database without demo data (remove `SEED_DEMO`), change all default passwords, empty `TEST_BANNER`.
