# Test report

Environment: Python 3.12, Flask 3.1.3, SQLite, headless Chromium (Playwright). Run: `python -m unittest discover -s tests -v`.
**Result: 45 tests run, 45 passed, 0 failed.** Two real bugs were found by the tests during development and fixed (returning-customers report parameter order; a restore-order problem in the new backup import).

## Covered by automated tests (on SQLite)
- Phone formats, duplicates, self/unknown/circular referrals.
- First skin analysis reward TZS 2,000 (only when fully paid; once only; database-level guard; not for returning visits).
- Returning price 15,000 standard / 10,000 with 2 qualifying referrals; partial or unpaid referrals do not count.
- Package commission 8% per instalment after discount, rounding, no commission without a referrer, overpayment refused.
- Reversals, voids, clawback adjustment after payout, re-earning after correction; approvals and payouts; settings history.
- Roles, CSRF, forced password change, lockout, disabled accounts, date and search limits.
- Seven reports with expected figures; Excel and PDF export for each; backup download (.db and ZIP of CSV); ZIP backup restored into a fresh database with identical counts and balances, including a referral link pointing to a later customer.
- Security: XSS escaping, SQL-injection strings, open redirect, security headers.
- PostgreSQL readiness checks: placeholder/percent translation, RETURNING id handling, PostgreSQL DDL contains no SQLite-only syntax, and a scan that application SQL uses no SQLite-only functions.

## Checked by hand in a running server (SQLite)
Health check, demo login, dashboard totals, customer account figures, phone-size (390 px) and desktop (1280 px) screenshots with no sideways scrolling, sale form JavaScript.

## Speed (SQLite, 3,000 customers, test client)
Pages 5-75 ms; Excel export of 2,000 rows 0.5 s; PDF export 3.9 s.

## NOT tested
- **PostgreSQL / Supabase:** there is no PostgreSQL in the test environment, so the PostgreSQL path has never been run. The first start against Supabase is its real test; expect that an error may need fixing.
- Nothing has been deployed: no public URL, gunicorn, Render or HTTPS run.
- Real phones, Safari/Firefox, many simultaneous users, penetration testing, opening exports in Microsoft Excel.
- Open decisions: price for returning customers without 2 referrals (standard price assumed); payments count as confirmed when staff record them; no SMS/WhatsApp or mobile-money integration; English only.
